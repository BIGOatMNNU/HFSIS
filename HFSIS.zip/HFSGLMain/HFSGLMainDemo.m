%%% HFSGLMain
% create by ZiLng Lin
% 2023-9-20
% 
load ('CLEFTrain.mat');

vAlpha = 0.01;
vBeta = 0.01;

[vReducedFeaturesB, vTime] = HFSGLMain(data_array, tree, vAlpha, vBeta);
vReducedFeaturesB'