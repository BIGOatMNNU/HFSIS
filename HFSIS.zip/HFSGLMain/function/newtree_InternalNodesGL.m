function [ middleNode ] = newtree_InternalNodesGL( tree )
%���ϵ��·����м�ڵ�
%���ö���˼��
root = tree_RootGL( tree );
middleNode=[];
middle = get_children_setGL(tree, root);
leafNode = tree_LeafNodeGL( tree );
while ~isempty(middle)
    if ~ismember(middle(1),leafNode)
        middleNode=[middleNode;middle(1)];
        temp = get_children_setGL(tree, middle(1));
        middle=[middle;temp];
    end
    middle(1)=[];
end
end

